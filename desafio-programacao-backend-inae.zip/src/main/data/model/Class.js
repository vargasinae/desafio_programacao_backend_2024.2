"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.classes = void 0;
exports.classes = [
    { classId: 1, className: 'Programação Backend', teacher: 'Vinicius', studentsRegistered: 3, schedule: 63 }
];
