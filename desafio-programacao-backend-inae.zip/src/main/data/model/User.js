"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.users = void 0;
exports.users = [
    { userName: 'Inae', email: 'inae@gmail.com', password: '123456', profile: 'ALUNO' },
    { userName: 'Gabriel', email: 'Gabriel@gmail.com', password: '123456', profile: 'PROFESSOR' },
];
